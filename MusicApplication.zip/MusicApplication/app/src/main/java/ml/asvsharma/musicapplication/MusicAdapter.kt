package ml.asvsharma.musicapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MusicAdapter(
   private var musicList: MutableList<Music>,
    private var itemClicked: ItemClicked
):RecyclerView.Adapter<MusicAdapter.MusicViewHolder>(){

    inner class MusicViewHolder(v:View):RecyclerView.ViewHolder(v), View.OnClickListener{
        private var view:View=v
        private lateinit var music:Music
        private var songName:TextView
        private var artistName:TextView
        init{
            artistName=view.findViewById(R.id.artist_name)
            songName=view.findViewById(R.id.song_name)
            view.setOnClickListener(this)
        }
        fun bindMusic(music:Music){
            this.music=music
            artistName.text=music.artistName
            songName.text=music.songName
        }
        override fun onClick(v: View?) {
           itemClicked.itemClicked(adapterPosition)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val context=parent.context
        val inflater=LayoutInflater.from(context)
        val shouldAttachToParentImmidiatly=false
        val view=inflater.inflate(R.layout.music_items,parent,false)
        return MusicViewHolder(view)
    }

    override fun getItemCount(): Int {
      return musicList.size
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
      val item=musicList[position]
        holder.bindMusic(item)
    }
}