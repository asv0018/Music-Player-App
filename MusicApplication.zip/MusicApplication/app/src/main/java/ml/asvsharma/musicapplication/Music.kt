package ml.asvsharma.musicapplication

data class Music (var artistName:String,var songName:String,var songUri:String)
