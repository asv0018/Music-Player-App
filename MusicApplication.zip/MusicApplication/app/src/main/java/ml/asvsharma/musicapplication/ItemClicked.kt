package ml.asvsharma.musicapplication

interface ItemClicked {
    fun itemClicked(position:Int){

    }
}